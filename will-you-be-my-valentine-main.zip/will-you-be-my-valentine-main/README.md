# Will you be my valentine?

**Valentine Page Creator**: https://i143.xyz/create


## Custom Templates
Click on the template of your choice, and create your valentine pages under 1 minute. : https://i143.xyz/templates

- **100% Free**. 🆓
- Easy to Use. **No Codeing** required. 🎉
- With **custom subdomain** of your choice (Obviously not claimed by anyone else). 🌍
- With **custom texts** of your choice. 💬
- With **custom images** of your choice. 👩‍❤️‍👨
- With **40 Beautiful** templates to start from. 🤩


# Demo
Github Pages : https://saurabhnemade.github.io/will-you-be-my-valentine/


# Description
This is a fun project for valentines day to bring smile on face of your special person!!

This project is inspired from
https://gist.github.com/tnarla/0c09a11fea366145ba684fe6ebf578c5 & https://www.tiktok.com/@mewtru/video/7331131143112166698

# How to start
```
npm install -g pnpm
pnpm i
pnpm run dev
```

# Preview

![image description](demo.gif)


# How to deploy it
```
pnpm run deploy
```

Made with ❤️ in Berlin!
